css:	stylesheets/dosasite.css
author:	David Loeffler
title:	Dosa Diner

# ![Restaurant Logo][1]Dosa Diner #


## The Restaurant ##
The Dosa Diner offers casual lunch and dinner fare in a hip atmosphere. The menu changes regularly to highlight the freshest ingredients.

## Catering Services ##
You have fun... we'll do the cooking. Dosa Diner Catering can handle events from snacks for bridge club to elegant corporate fundraisers.

## Location and Hours ##
Deccan Corner in Pune, India;
Monday through Thursday 11am to 9pm, Friday and Saturday, 11am to midnight

[1]: images/dosa.jpg "Restaurant Logo"